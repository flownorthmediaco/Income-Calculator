
# Job Income Allocation Calculator (PWA)

A mobile-friendly Progressive Web App (PWA) that helps photographers and freelancers allocate income by percentage.

## 🔢 Features
- Instant breakdown of income by category:
  - 30% Federal & State Taxes
  - 7% Sales & Use Taxes
  - 10% Tithe
  - 28% Savings
  - 5% Expenses
  - 20% Owner’s Draw
- Fully responsive layout for mobile and desktop
- Installable as a home screen app

## 📱 How to Use
1. Open the app in your mobile browser.
2. Enter your job income.
3. View automatic breakdown by category.
4. Tap **“Add to Home Screen”** to install as an app.

## 🚀 Deploy to GitHub Pages
1. Create a new public repo on GitHub.
2. Upload these files:
   - `index.html`
   - `manifest.json`
   - `service-worker.js`
   - `icon.png`
   - Your logo (optional)
   - `README.md`
3. Go to **Settings → Pages** and deploy from `main` branch, `/root`.
4. Your PWA will be live!

## 📄 License
MIT License
